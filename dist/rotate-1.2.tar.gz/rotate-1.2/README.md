## About Rotate
This project contains tools for reading and writing files and algorithms
for encryption. 
***
Run the main module to open the CLI menu. The "reading" module contains
functions for reading text from a file and writing to a file. The "ciphers"
module contains algorithms for char-by-char text encryption.