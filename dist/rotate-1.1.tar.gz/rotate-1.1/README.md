This project contains tools for reading and writing files and algorithms for
encryption. To enter the program menu, run the 'rotate' package. Ready-made
examples are located in the 'example' module. To import the 'reading' module
for reading and writing the text; to import the 'ciphers' module for reading
and writing the text.